use rand::Rng;
//use rand_distr::{StudentT, Distribution};
//use std::env;
use std::fs::File;
use close_file::{Closable, CloseError};

use std::io::Write;
use std::path::PathBuf;


fn write_to_file_test() {
    // Create a temporary file.
    //let temp_directory = env::current_dir();
    let temp_file = PathBuf::from(r"testfile.txt"); //party like it is 198x
 
    // Open a file in write-only (ignoring errors).
    // This creates the file if it does not exist (and empty the file if it exists).
    let mut file = File::create(temp_file).unwrap();

    // Write a &str in the file (ignoring the result).
    writeln!(&mut file, "Hello World!").unwrap();

    // Write a byte string.
    file.write(b"Some Bytes written \n").unwrap();

    let mut resultat = file.close(); //closing of files is handled different from most languages as a separate set of errors (see: https://docs.rs/close-file/latest/close_file/ )
}


// fn test_vectors() {
//     let mut x:Vec<DataStruktur> = Vec::new();
//     for p in 1..=101 {
//         let m = p+99;
//         let mut some = DataStruktur {g:p,h:m};
//         some.g = some.g + 1;
//         some.h = some.h + 2;
//         x.push(some);
//     }
//     println!("Print vector:");
//     println!("{:?}", x); //prints entire vector!
// }



// //derive is required to allow printing of the vectored struct
// #[derive(Debug)] 

// struct DataStruktur {
//     g: i32,
//     h: i32,
// }

// fn test_vector_of_vectors() {
//     let vec_of_vecs: Vec<Vec<u64>> = vec![ vec![1, 2, 3], vec![4, 5, 46], vec![7, 8, 9] ];
//     println!("{:#?}", vec_of_vecs);
// }
fn get_random()->f32 {
//    let t = StudentT::new(11.0).unwrap();
//    let v = t.sample(&mut rand::thread_rng());
    let mut rng = rand::thread_rng();
    let v: f32 = rng.gen(); // generates a float between 0 and 1
    return (v);
}

fn make_random_genome(size:u16)-> Vec<f32>{
    let mut result:Vec<f32>=Vec::new();

    for p in 0..=(size-1) {
        let maxval:f32 = GENE_MAX[p as usize] ;
        let minval:f32 = GENE_MIN[p as usize];
        let delta:f32 = maxval - minval;
        result.push( (get_random()*delta) + minval);
    }
    println!("GenomeX{:#?}", result);
    return result;
}

//#[derive(Debug, PartialEq, PartialOrd, Clone, Copy)]
type TGene = Vec<f32>;

// the model needs capacity in Farad and Resistance in Ohm
//let GENE_MAX :Vec<f32>= vec![10000.0, 100.0]; //not const since vec![] is dynamic alloc
//let GENE_MIN :Vec<f32>= vec![0.1, 0.1]; //not const since vec![] is dynamic alloc
static GENE_MAX: &'static [f32] = &[10000.0, 100.0];
static GENE_MIN: &'static [f32] = &[0.1, 0.1];
/// freepascal: const GENE_MIN : Array [0..1] of single = (0.1, 0.1);


// https://rust-lang-nursery.github.io/rust-cookbook/algorithms/sorting.html

const NUM_OF_GENES:u16=2;

#[derive(Debug, PartialEq, PartialOrd, Clone)]
pub struct TIndivid {
    pub genes:TGene,
    pub fitness: f32
}

impl TIndivid {
    pub fn new(genes: TGene, fitness: f32) -> Self {
        TIndivid {
            genes,
            fitness
        }
    }

}

#[derive(Debug, PartialEq, PartialOrd, Clone)]
pub struct TPopulation{
    pub population:Vec<TIndivid>,
    pub population_size:u32,
    pub current_generation:u32,
    pub max_generation:u32,
    pub best_fitness:Vec<f32>,
    pub avg_fitness:Vec<f32>,
    pub worst_fitness:Vec<f32>,
     /// in range 0-1
    pub mutation_rate:f32,
     /// in range 0-1
    pub mutation_intensity:f32,
     /// in range 0-1
    pub elite_size:f32, 
    /// in range 0-1
    pub crossover_size:f32
}

impl TPopulation {
    pub fn new(max_generation:u32, mutation_rate:f32, mutation_intensity:f32) -> Self {
        TPopulation { population : vec![], population_size: 0, 
            current_generation: 0, max_generation: max_generation, 
            best_fitness: vec![], avg_fitness: vec![], worst_fitness: vec![], 
            mutation_rate: mutation_rate, mutation_intensity:mutation_intensity , elite_size: 0.1, crossover_size: 0.2 }
    }
    pub fn make_population(&mut self, population_sizer:i32) {
        for p in 0..population_sizer {
            self.population.push(TIndivid::new(make_random_genome(NUM_OF_GENES), get_random()));
        }
    }
    pub fn sort_population(&mut self){
        self.population.sort_by(|a, b| a.fitness.partial_cmp(&b.fitness).unwrap()) ;    
    }
    pub fn print_population(&mut self){
        for p in 0..self.population.len() {
            println!("{}",self.population[p].fitness);
        }
    }
}

const MIN_VAL:f32 = -10.0; 
const MAX_VAL:f32 = 100.0; 

fn test_sorting_functions() {
    let mut people = vec![
        TIndivid::new(make_random_genome(NUM_OF_GENES), 25.0),
        TIndivid::new(make_random_genome(NUM_OF_GENES), 60.0),
        TIndivid::new(make_random_genome(NUM_OF_GENES), 1.0),
    ];

    //Sort population by Fitness
    people.sort_by(|a, b| a.fitness.partial_cmp(&b.fitness).unwrap()) ;
    for p in 0..people.len() {
        println!("{}",people[p].fitness);
    }
    //println!("{:?}", people); //prints entire vector!
}

fn limit_values(item:TIndivid) -> TIndivid {
    //let mut resultat =TIndivid::new(make_random_genome(NUM_OF_GENES), 25.0);
    let mut resultat = item.clone();
    for p in 0..resultat.genes.len() {
        let maxval:f32 = GENE_MAX[p as usize] ;
        let minval:f32 = GENE_MIN[p as usize];
        if resultat.genes[p] > maxval { resultat.genes[p] = maxval;  }
        if resultat.genes[p] < minval { resultat.genes[p] = minval;  }
    }
    return resultat;
}
/******************************************************************
    Name        : crossover
    Input       : Two TIndivid that should be crossed
    resultat    : Based on fitness the resulting genes are crossed. Fitness in TIndivid is set to -1.0 (no fitness) 
    Description : Simple crossover operator for floats
******************************************************************/
fn crossover(item1:TIndivid,item2:TIndivid)->TIndivid {
    let mut resultat =TIndivid::new(make_random_genome(NUM_OF_GENES), 25.0); //Values are not used, but we reserve space for record
    // item1.genes.to_vec(); //to_vec Copies content not just reference
    for p in 0..item1.genes.len() {
        resultat.genes[p] = ((item1.genes[p]*item1.fitness + item2.genes[p]*item2.fitness)/
                             (item1.fitness + item2.fitness));
    }
    resultat.fitness = -1.0; //Destroy fitness value
    return resultat;
}

/******************************************************************
    Navn        : Muter_tal
    inddata     : tal=gammelt tal, i=antal generationer indtil nu,
                  maxgen=maximalt antal generationer i det hele taget
    uddata      : tal +/- mutation
    beskrivelse : Dette system muterer tal med faldende intensitet,
                  som funktion af antal generationer
                  (note: intensitet= hvor *MEGET* muteres det enkelte tal
                         rate      = hvor *OFTE* muteres der i det hele taget!)
                  resultatet ligger i intervallet 
                   [tal - mutations_intensitets_faktor;tal + mutations_intensitets_faktor]
    ******************************************************************)
    fun muter_tal (tal:real,i,maxgen)=
        let val intensitet=(1.0 - (Real.fromInt(i) / Real.fromInt(maxgen))) * mutations_intensitets_faktor
        in
            tilfaeldighed_begraenset(tal - intensitet,tal + intensitet) 
        end;
   fun tilfaeldighed_begraenset(min:real, max:real)=(Random.random tilfaeldighedsgenerator)*(max-min) + min;
*/

/// Returns a person with the name given them
/// # Arguments
/// * 'item' - TIndivid to be mutated
/// * 'current_gen' - current generation
/// * 'max_gen' - maximum allowed generations
/// * '

// fn mutate (item:TIndivid, current_gen:u32 , max_gen:u32, mutation_intensity:f32 , mutation_rate:f32)-> TIndivid {
// {
//      let mut intensitet_factor:f32=(1.0 - ((current_gen as f32)) / (max_gen as f32)) * mutations_intensitets_faktor;
//      tilfaeldighed_begraenset(tal - intensitet,tal + intensitet) ;
// }

pub(crate) fn main() {
    let mut value:f32 =0.0;
    // println!("Test of vectors");
    // println!("------------------------------------------------------------");
    // test_vectors();
    // println!("------------------------------------------------------------");
    // println!("Test of random");
    // println!("------------------------------------------------------------");
    // // value = get_random();
    // // println!("Random value = {} ", value);
    // for my_idx in  1..100 {
    //     value = get_random();
    //     print!("{}, ", value);
    // }
    // println!("------------------------------------------------------------");
    // println!("Test of files");
    // println!("------------------------------------------------------------");
    // write_to_file_test();
    // println!("------------------------------------------------------------");

    println!("Test of vectors");
    println!("------------------------------------------------------------");
    //test_vector_of_vectors();

    test_sorting_functions();
    let mut population = vec![
        TIndivid::new(make_random_genome(NUM_OF_GENES), 1.0),
        TIndivid::new(make_random_genome(NUM_OF_GENES), 3.0),
        TIndivid::new(make_random_genome(NUM_OF_GENES), 2.0),
    ];
    let mut resvec:TIndivid = crossover(population[0].to_owned(), //needs to own even though we copy internally
                                       population[1].to_owned());
    println!("Gene1= {:?}", population[0].genes);
    println!("Gene2= {:?}", population[1].genes);
    println!("crossed genes= {:?}", resvec.genes);

    population[0].genes[0] = GENE_MAX[0 as usize]*25.0; //
    population[0].genes[1] = GENE_MAX[1 as usize]*25.0; //
    println!("Gene1= {:?}", population[0].genes);
    population[0] = limit_values(population[0].to_owned());
    println!("Gene1= {:?}", population[0].genes);

    let mut pop = TPopulation::new(10, 0.1 , 0.1); 
    pop.make_population(20);
    pop.print_population();
    pop.sort_population();
    pop.print_population();
    println!("------------------------------------------------------------");
    println!("Done!");
}
